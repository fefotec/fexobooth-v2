# Handoff: fexobox Kiosk-UI Redesign (fexobooth-v2)

## Overview
Redesign der Gäste-Oberfläche der Fotobox-Software `fexobooth-v2` (Python / CustomTkinter, Lenovo Miix 310, 1280×800 quer, Touch, Vollbild).
Ziel: moderner, hochwertiger, freundlicher – als **Evolution** des bestehenden Dark-Themes. Ablauf und Position der Hauptelemente bleiben erhalten (Start → Session → Filter → Final; Drucker-Dialog als Overlay).

Betroffene Dateien im Repo:
- `src/ui/theme.py` (Tokens)
- `src/ui/screens/start.py`, `session.py`, `filter.py`, `final.py`
- `src/ui/dialogs/printer_error.py`
- `src/i18n.py` (neue/geänderte Strings DE/FR/EN)

## About the Design Files
Die Dateien in diesem Paket sind **Design-Referenzen in HTML** (`Redesign.dc.html`, `Ist-Zustand.dc.html`). Sie sind kein Produktionscode. Aufgabe ist, die Screens **1:1 in CustomTkinter** nachzubauen – mit den Werten aus diesem README und dem Komponenten-Blatt (unterster Artboard in `Redesign.dc.html`). `Ist-Zustand.dc.html` zeigt die heutige UI zum Vergleich.

## Fidelity
**High-fidelity.** Alle Farben, Größen, Radien, Schriftgrößen und Abstände sind final und werden 1:1 übernommen. Wo CustomTkinter eine Eigenschaft nicht kann (z. B. Bild-Clipping mit Radius), gilt: weglassen, nicht simulieren.

## Harte technische Grenzen (nicht verhandelbar)
1. Feste Auflösung 1280×800, kein Scrollen, jeder Screen passt auf eine Seite.
2. Erlaubt: einfarbige Flächen (`fg_color`), abgerundete Ecken (`corner_radius`), 1–3 px Rahmen (`border_width/border_color`), Segoe UI Regular/Semibold/Bold, statische PNGs (`CTkImage`). Verläufe/Schatten/Illustrationen nur **in PNGs eingebacken**.
3. Verboten: Animationen, Übergänge, Blur, Echtzeit-Verläufe/-Schatten, Videohintergründe, Icon-Fonts, Emojis in Labels, Hover-Effekte. Gedrückt-Zustände nur als Farbwechsel.
4. Live-Kamerabild (Session) ist eine feste Fläche 1000×670; drumherum nichts, das sich bewegt oder laufend neu zeichnet.
5. Hauptbuttons ≥ 88 px hoch, **ein** dominanter Pink-Button pro Screen.
6. Texte DE + FR (+ EN vorhanden), Buttons ~30 % Längenreserve.
7. Neue Bild-Assets gesamt < 15 MB (Plan ≈ 2 MB).

## Design Tokens → `src/ui/theme.py`

### Farben (`COLORS`)
| Token | Hex | Verwendung |
|---|---|---|
| `primary` | `#E00675` | Hauptbutton, Auswahl-Rahmen, Badge, Fortschritt, Eyebrow-Text, Countdown |
| `primary_pressed` | `#B8005E` | Hauptbutton gedrückt |
| `bg_dark` | `#08080C` | Screen-Hintergrund, Vorschau-Flächen, Countdown-Kontur |
| `bg_medium` | `#14141C` | Panels (QR, Review-Leiste, Render-Panel, Dialog-Karte), Tertiary-Button |
| `bg_light` | `#1F1F29` | Secondary-Button, deaktivierter Button, Fortschritts-Spur |
| `bg_card` | `#212130` | Layout-Karten, Filter-Kacheln |
| `border` | `#2C2C3A` | Standard-Rahmen 1–2 px, Trennlinien, offene Fortschritts-Pills |
| `border_light` | `#3A3A48` | Secondary-Button-Rahmen, Dialog-Rahmen, gedrückt Secondary |
| `pressed_secondary` | `#2C2C3A` | Secondary/Tertiary gedrückt (Fläche) |
| `text_primary` | `#FFFFFF` | |
| `text_secondary` | `#A6A6B6` | |
| `text_muted` | `#5C5C6C` | deaktivierte Labels, Micro-Text |
| `paper` | `#F4F2EF` | Collagen-Träger in Vorschauen (optional, sonst #FFFFFF) |
| `white` | `#FFFFFF` | QR-Träger, Drucker-Illustrations-Träger |

**Entfällt in der Gäste-UI:** `success #00D26A`, `error #FF4757`, `warning #FFB800`, `info`, Cyan `#16D6C7`, alle `START_COLORS` in `start.py` (`#111521 #181C2A #222638 #0B0E16 #343A4F #58617C`). `primary_hover #FF1493` → `hover_color` immer = Normalfarbe setzen (Touch).
Verlauf `#E00675 → #687FFC` **nur** in PNG-Assets.

### Typografie (`FONTS`, Segoe UI)
| Token | Größe / Schnitt | Einsatz |
|---|---|---|
| `display` | 44 bold | Start-Titel |
| `h1` | 36 bold | Filter-/Final-Titel |
| `h2` | 28 semibold (`"Segoe UI Semibold"`) | „Dein Bild wird erstellt …“ |
| `h3` | 26 semibold | Kartentitel, „Foto 2 von 4“ |
| `button_xl` | 28 bold | START, DRUCKEN |
| `button` | 26 bold | WEITER, NOCHMAL, VERSTANDEN |
| `button_s` | 22 bold | FERTIG |
| `body` | 20 regular | Untertitel, Dialog-Text |
| `label` | 18 semibold | Filter-Namen, Tertiary-Button, Eyebrow (Versalien) |
| `caption` | 16 regular | „3 Ausdrucke verfügbar“, Auto-Rückkehr |
| `small` | 15 regular / semibold | QR-Panel Zeilen |
| `micro` | 14 regular | Dialog-Hinweis |
| `countdown` | 360 bold (PIL, ins Kamerabild) | unverändert: Pink, 5–7 px Kontur `#08080C` |

Semibold in Tk: Font-Family `"Segoe UI Semibold"` mit `weight="normal"`. Button-Labels in Versalien mit ~4 % Sperrung (Tk kann kein letter-spacing → Label-Text als Großbuchstaben, keine Sperrung nötig).

### Radien (`SIZES`)
`radius_dialog` 28 · `radius_card` 24 (Karte, Panel) · `radius_button` 20 · `radius_tile` 16 (Filter-Kachel, Tertiary-Button, Karten-Vorschaufläche, QR-Träger) · `radius_thumb` 12 · Pills = Höhe/2.

### Abstände
Seitenrand 80 · Top-Bar 72 (Inhalt 40 vom Rand) · Karten-Gap 40 · Kachel-Gap 24 · Button-Gap 32 · Stacks 8/16/24 · Karten-Innen 22 (bei 3 px Rahmen 21, Außenmaß konstant) · Kachel-Innen 12 (ausgewählt 11) · Dialog-Innen 40 oben/60 seitlich/36 unten.

### Rahmen
1 px Panel · 2 px Karte/Button/Kamera-Rahmen · 3 px ausgewählt (Pink).

## Komponenten

### Buttons (nur Farbwechsel; `hover_color` = `fg_color`; Gedrückt via `<ButtonPress-1>`/`<ButtonRelease-1>`)
| Typ | Maße | normal | gedrückt | deaktiviert |
|---|---|---|---|---|
| Primary | h 88 (96 bei START/DRUCKEN), min-w 320, r 20, 26/28 bold, Text #FFF | fg `#E00675` | fg `#B8005E` | fg `#1F1F29`, Text `#5C5C6C` |
| Secondary | h 88 (72 bei FERTIG), r 20, Rahmen 2, 26/22 bold, Text #FFF | fg `#1F1F29`, border `#3A3A48` | fg `#2C2C3A` | fg `#1F1F29`, border `#2C2C3A`, Text `#5C5C6C` |
| Tertiary (Abbrechen, Fotos nochmal) | h 56, pad 0 28, r 16, Rahmen 2, 18 semibold | fg `#14141C`, border `#2C2C3A`, Text `#A6A6B6` | fg `#1F1F29`, border `#3A3A48`, Text #FFF | Text `#5C5C6C` |

### Layout-Karte (Start)
380×330, r 24, fg `#212130`, border 2 `#2C2C3A`, Innen 22. Vorschaufläche 332×200, r 16, fg `#08080C`, Template-Preview per `thumbnail((300,170))`. Titel 26 semibold (mt 18), Untertitel 17 regular `#A6A6B6` (mt 4).
Ausgewählt: border 3 `#E00675`, Innen 21, Badge `icon_check_40.png` (40×40, Pink-Kreis mit weißem Haken) oben rechts bei 16/16. Keine Hover-Bindings.

### Filter-Kachel
262×224, r 16, fg `#212130`, border 2 `#2C2C3A`, Innen 12. Thumb 238×158 r 12 (Bild per PIL auf 238×158 gefittet, Ecken via PIL-Maske wie heute `_round_corners`, Radius 12). Name 18 semibold #FFF (mt 12).
Ausgewählt: border 3 Pink, Innen 11, Name `#E00675`, Badge `icon_check_36.png` bei 12/12.

### Fortschritt
- Foto-Schritte: Pills 40×10 r 5, gap 8; erledigt + aktuell `#E00675`, offen `#2C2C3A`.
- Auto-Weiter/Rückkehr: `CTkProgressBar` h 6 r 3, fg `#1F1F29`, progress `#E00675`, Update max. 2×/s (heute 10×/s → auf 500 ms).
- Render-Fortschritt: 5 Segmente 56×8 r 4, gap 8; pro Render-Schritt ein Segment Pink – **kein** indeterminate-Modus.

### QR-Panel
288 breit, fg `#14141C`, r 24, border 1 `#2C2C3A`, Innen 24, zentriert. Titel 22 semibold; Sub 15 `#A6A6B6` (mt 6); QR-Träger 224×224 #FFF r 16 mit QR 200×200 (mt 18); Caption „EVENT-CODE“ 14 semibold `#A6A6B6` (mt 18); Code 30 bold `#E00675`; Trennlinie 1 px `#2C2C3A` (my 16); „WLAN: ssid“ 15 semibold #FFF; „Passwort: …“ 15 regular `#A6A6B6` (mt 4).

## Screens (alle 1280×800, Hintergrund `#08080C`)

### 1 · Start (`start.py`)
- Hintergrund-PNG `bg_glow_start.png` 1280×800 als `CTkLabel` mit Bild auf (0,0) hinter allem (`place`), darauf alle Widgets mit `fg_color="transparent"` bzw. eigener Fläche.
- Logo `fexobox-logo-voll-ohne-verlauf-weiss.png` Höhe 96 bei (44, 14).
- Textblock bei (80, 128): Eyebrow „WILLKOMMEN“ 18 semibold Pink; Titel „Wähle dein Foto-Layout“ 44 bold; Sub „Tippe auf eine Karte und drücke Start.“ 20 `#A6A6B6`; Zeilenabstand 8.
- Karten-Reihe bei (80, 270), gap 40: „Standard 2×2 / Druck-Vorlage · 4 Fotos“ (vorausgewählt), „Einzelfoto / Ein großes Bild“ (Preview `card_single.png` 210×140). Bei 1 Karte: zentriert im Bereich 80–880; bei 3 Karten: Breite 253, Vorschau 205×124, Titel 22.
- START-Button 480×96 bei (240, 656), Primary, `button_xl`. Deaktiviert-Zustand bis Auswahl (heute schon so).
- QR-Panel bei (944, 128) (nur wenn Galerie aktiv; sonst Karten-Reihe zentriert über 1280: x = (1280 − 800)/2 = 240).
- Loading-Overlay (VLC-Warmup): gleiche Struktur wie heute, aber Ladebalken als 5-Segment-Anzeige oder statischer Balken; Text-Größen h2/body/caption.

### 2 · Session (`session.py`)
- Top-Bar 72 hoch, transparent: links „Foto 2 von 4“ 26 semibold + 4 Fortschritts-Pills (gap 20 zum Text); rechts Tertiary „Abbrechen“ (h 56). Inhalt 40 vom Rand.
- Kamera-Rahmen: `tk.Frame`/`CTkFrame` 1004×674 bei (138, 72), border 2 `#2C2C3A`, `corner_radius=0`; innen Kamerabild 1000×670. **Hintergrund des Containers `#08080C`, nicht mehr #FFFFFF.**
- Countdown: unverändert per PIL in den Frame gezeichnet (Größe ≈ Bildhöhe/2, Pink, Kontur `#08080C`).
- Hinweiszeile unter der Kamera (y 746–800): 20 regular `#A6A6B6`, zentriert; Countdown „Schau in die Kamera – gleich geht's los!“, Review „Gefällt dir das Foto?“.
- Review-Leiste (nach Foto, wie heute per `place` über dem Bild-Unterrand): 1000×128, fg `#14141C`, oben 2 px `#2C2C3A`; Buttons NOCHMAL (Secondary 320×88) und WEITER (Primary 320×88), gap 32, zentriert. Ersetzt die rote/grüne Leiste auf `#000000`.

### 3 · Filter (`filter.py`)
- Titel „Wähle deinen Look“ 36 bold bei (80, 40); Sub „Tippe auf einen Filter – die Vorschau zeigt dein Bild.“ 18 `#A6A6B6` (mt 6). Rechts oben Tertiary „Fotos nochmal“ (rechtsbündig 80, y 48).
- Kachel-Grid 4×2 bei (80, 144), Zellen 262, gap 24, 8 Filter (`AVAILABLE_FILTERS`). Jede Kachel zeigt **dasselbe Foto** (Collage-Preview) mit jeweiligem Filter – die separate große Vorschau entfällt (Kacheln sind groß genug). Reihenfolge: Original, Schwarz-Weiß, BW Kontrast, Sepia, Cool Breeze, Vivid Pop, Filmisch, Insta Glow; „Original“ vorausgewählt.
- Auto-Weiter-Balken 1120×6 bei (80, 652). Text links „Ohne Auswahl geht es in 12 Sekunden automatisch weiter“ 18 `#A6A6B6` (vertikal mittig zu Button, y 688–776; Sekunden live, Update 1×/s).
- WEITER Primary 400×88 rechtsbündig (x 800, y 688).

### 4 · Final (`final.py`)
- Titel bei (80, 40): fertig → „Dein Bild ist fertig!“ 36 bold + Sub „Drucken oder einfach Fertig tippen – das Foto ist gespeichert.“; Rendering → „Einen Moment …“ + „Deine Fotos werden zur Collage zusammengesetzt.“
- Bild 780×520 bei (80, 144) (1800×1200-Collage gefittet, Träger `#F4F2EF`/weiß aus Template).
- Rechte Spalte x 920, Breite 280, ab y 144, gap 16: DRUCKEN Primary 280×96 `button_xl`; Caption „3 Ausdrucke verfügbar“ 16 `#A6A6B6` zentriert; FERTIG Secondary 280×72 (`button_s`, mt +8).
- Zustand „Dein Bild wird erstellt …“: statt Bild ein Panel 780×520, fg `#14141C`, r 24, border 1 `#2C2C3A`; zentriert `illu_rendering_160.png` (160×160), h2 „Dein Bild wird erstellt …“ (mt 28), 18 `#A6A6B6` „Das dauert nur ein paar Sekunden“, 5-Segment-Fortschritt (mt 28). Beide Buttons deaktiviert.
- Auto-Rückkehr: Text „Automatisch zurück zum Start in 45 Sekunden“ 16 `#A6A6B6` bei (80, 712); Balken 1120×6 bei (80, 752).
- Mengen-Dialog (`_show_print_quantity_dialog`): Karte fg `#14141C`, r 28, border 2 `#3A3A48`; Zahlen-Buttons Primary-Farben statt Grün; Abbrechen Secondary.

### 5 · Drucker-Hinweis (`printer_error.py`)
- Vollfläche `#08080C`. Karte 760 breit zentriert, fg `#14141C`, r 28, border 2 `#3A3A48` (kein roter Rahmen mehr), Innen 40/60/36.
- Illustration: bestehende `assets/error_images/*.png` in weißem Träger 200×200 r 20, Bild 184×184.
- Eyebrow „KURZE PAUSE“ 18 semibold Pink (mt 28); Titel 34 bold (mt 8), z. B. „Papier wird gewechselt“ / „Farbkassette wird gewechselt“ / „Kleiner Papierstau“; Body 20 `#A6A6B6`, wraplength 560, Zeilenhöhe 1.4 (mt 14): „Unser Team legt gerade neues Fotopapier ein. Dein Foto bleibt gespeichert und wird gleich gedruckt.“
- Bestätigen-Button Primary 400×88 „VERSTANDEN“ (mt 32). Für Personal-Aktionen (PAPIER EINGELEGT etc.) derselbe Button mit dem bestehenden Text. Papierstau-Variante: kein Button, stattdessen 5-Segment-Fortschritt (Reset-Schritte) und Hinweis „Bitte nicht ausschalten“.
- Hinweis 14 `#5C5C6C` (mt 20): „Danach geht es ganz normal weiter.“
- Service-Schließen-Button (×) oben rechts bleibt, 44×44, Text `#5C5C6C`.

## Interaktion & Zustände
- Kein Hover: alle `hover_color` = `fg_color`; `<Enter>/<Leave>`-Bindings in `TemplateCard`/`FilterCard` entfernen.
- Gedrückt: `<ButtonPress-1>` setzt `fg_color` auf pressed-Farbe, `<ButtonRelease-1>` zurück (≤ 1 configure-Aufruf je Ereignis).
- Auswahl: `set_selected()` ändert nur `border_color`, `border_width` (2→3), Innenabstand (22→21 / 12→11) und blendet das Check-Badge ein (`place`/`place_forget`).
- Session-Zustände: `countdown` (Hinweistext A, Leiste versteckt) → `review` (Hinweistext B, Leiste per `place` eingeblendet). Kamerabild bleibt unangetastet.
- Final-Zustände: `rendering` (Panel + deaktivierte Buttons) → `ready` (Bild + aktive Buttons) → `printing` (DRUCKEN deaktiviert, Caption „Druckauftrag gesendet · noch 2 verfügbar“).
- Timer-Updates (Auto-Weiter, Auto-Rückkehr) max. 2×/s; Ladebalken nie im indeterminate-Modus.

## i18n (`src/i18n.py`) – neue/geänderte Schlüssel
| Key | DE | FR |
|---|---|---|
| `start.eyebrow` | Willkommen | Bienvenue |
| `start.choose_mode` | Wähle dein Foto-Layout | Choisis ton format photo |
| `start.tap_option` | Tippe auf eine Karte und drücke Start. | Appuie sur une carte, puis sur Démarrer. |
| `start.standard_2x2_sub` | Druck-Vorlage · 4 Fotos | Format d'impression · 4 photos |
| `start.single_photo` | Einzelfoto | Photo seule |
| `start.single_subtitle` | Ein großes Bild | Une grande image |
| `common.start` | START | DÉMARRER |
| `gallery.banner_title` | Fotos aufs Handy | Photos sur ton téléphone |
| `gallery.banner_sub` | QR-Code mit der Handykamera scannen | Scanne le QR code avec ton téléphone |
| `session.redo` | NOCHMAL | ENCORE |
| `session.continue` | WEITER | CONTINUER |
| `session.hint_countdown` | Schau in die Kamera – gleich geht's los! | Regarde la caméra – c'est parti ! |
| `session.hint_review` | Gefällt dir das Foto? | Cette photo te plaît ? |
| `filter.choose_style` | Wähle deinen Look | Choisis ton style |
| `filter.hint` | Tippe auf einen Filter – die Vorschau zeigt dein Bild. | Appuie sur un filtre – l'aperçu montre ta photo. |
| `filter.back_redo` | Fotos nochmal | Refaire les photos |
| `filter.continue` | WEITER | CONTINUER |
| `filter.auto_continue` | Ohne Auswahl geht es in {seconds} Sekunden automatisch weiter | Sans sélection, on continue automatiquement dans {seconds} secondes |
| `final.title_ready` | Dein Bild ist fertig! | Ta photo est prête ! |
| `final.sub_ready` | Drucken oder einfach Fertig tippen – das Foto ist gespeichert. | Imprime-la ou appuie sur Terminé – la photo est enregistrée. |
| `final.title_rendering` | Einen Moment … | Un instant … |
| `final.rendering` | Dein Bild wird erstellt … | Ta photo est en cours de création … |
| `final.rendering_sub` | Das dauert nur ein paar Sekunden | Cela ne prend que quelques secondes |
| `final.auto_return` | Automatisch zurück zum Start in {seconds} Sekunden | Retour automatique à l'accueil dans {seconds} secondes |
| `final.prints_available` | {remaining} Ausdrucke verfügbar | {remaining} impressions disponibles |
| `printer.eyebrow` | Kurze Pause | Petite pause |
| `printer.title_paper` | Papier wird gewechselt | Changement de papier |
| `printer.body_paper` | Unser Team legt gerade neues Fotopapier ein. Dein Foto bleibt gespeichert und wird gleich gedruckt. | Notre équipe recharge le papier photo. Ta photo reste enregistrée et sera imprimée juste après. |
| `printer.after_hint` | Danach geht es ganz normal weiter. | Ensuite, tout continue normalement. |
| `common.understood` | VERSTANDEN | COMPRIS |

Alle Emojis/Pfeile (🎨 ✨ 📸 ↻ → ▶) aus bestehenden Strings entfernen. EN-Varianten analog ergänzen.

## Assets (`assets/icons/` bzw. `assets/ui/`)
| Datei | Maße | Inhalt | ≈ Größe |
|---|---|---|---|
| `bg_glow_start.png` | 1280×800 | `#08080C` mit weichem Glow: Pink `#E00675` (≈35 % Deckung) oben links, Blauviolett `#687FFC` (≈25 %) oben mittig; unteres Drittel rein `#08080C` | 900 KB |
| `fexobox-logo-voll-ohne-verlauf-weiss.png` | vorhanden | Logo, auf 96 px Höhe skaliert | 40 KB |
| `card_single.png` | 210×140 | Heller Bildträger `#F4F2EF` r 6 mit einer Fläche `#C8C4D4` | 30 KB |
| `icon_check_40.png`, `icon_check_36.png` | 40×40 / 36×36 | Pink-Kreis `#E00675`, weißer Haken 3 px | 4 KB |
| `illu_rendering_160.png` | 160×160 | Kachel r 32 mit Verlauf Pink→Blauviolett, mittig weißes Foto-/Funkel-Motiv | 60 KB |
| `printer_no_paper.png`, `printer_ink_casette.png`, `printer_paper_jam.png` | vorhanden | in weißem Träger 200×200 auf 184 px | 3×150 KB |
| QR | 200×200 | generiert (`qrcode_gen.py`) | – |

Gesamt ≈ 2 MB (Budget 15 MB). Alle PNGs einmal beim Screen-Aufbau laden und als `CTkImage` cachen.

## Umsetzungsreihenfolge (Vorschlag)
1. `theme.py`: Tokens, Fonts, Radien ersetzen; `get_button_style()` um `pressed`/`disabled` erweitern; Hilfsfunktion `bind_pressed(button, normal, pressed)`.
2. `start.py`: `START_COLORS` entfernen, Karte/Badge/QR-Panel/Glow-PNG.
3. `session.py`: Top-Bar, Kamera-Rahmen, Hinweiszeile, Review-Leiste.
4. `filter.py`: Grid 4×2 mit Foto-Kacheln, große Vorschau entfernen, Auto-Weiter-Text.
5. `final.py`: Layout Bild links / Buttons rechts, Render-Panel, Mengen-Dialog.
6. `printer_error.py`: Karte, Eyebrow/Titel/Body, Primary-Button.
7. `i18n.py`: Strings DE/FR/EN.
8. Prüfen auf dem Tablet: Frame-Time Session-Screen unverändert, kein Widget im Kamerabereich zeichnet periodisch.

## Files
- `Redesign.dc.html` – 5 Screens + Komponenten-Blatt (Tweaks: Sprache DE/FR, Session-/Final-Zustand). Im Browser öffnen, benötigt `support.js` im selben Ordner.
- `Ist-Zustand.dc.html` – heutige UI aus `src/ui`, zum Vergleich.
- `assets/` – Logo, Drucker-Illustrationen, Referenzen.
